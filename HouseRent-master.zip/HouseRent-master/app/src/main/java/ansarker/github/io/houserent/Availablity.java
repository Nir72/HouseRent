package ansarker.github.io.houserent;

import ansarker.github.io.houserent.model.Rent;
import ansarker.github.io.houserent.model.User;

public class Availablity {

    public static User currentUser;
    public static Rent currentRent;
}
